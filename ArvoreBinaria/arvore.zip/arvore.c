#include <stdio.h>
#include <stdlib.h>
#include "arvore.h"

void Iniciar(TCelula **no){
    *no = NULL;
}

TCelula *criaNo(TItem Item){
    TCelula *no = (TCelula*) malloc(sizeof(TCelula));
    no->pai = NULL;
    no->esq = NULL;
    no->dir = NULL;
    no->item = Item;
    return no;
}

void Inserir(TCelula **x, TCelula *pai, TItem Item){
    if((*x) == NULL){
        (*x) = criaNo(Item);
        if(pai != NULL)
            (*x)->pai = pai;
        return;
    }
    if((*x)->item.chave > Item.chave){
        Inserir(&(*x)->esq, (*x), Item);
        return;
    }
    if ((*x)->item.chave <= Item.chave)
        Inserir(&(*x)->dir, (*x), Item);
}

TCelula* Pesquisar(TCelula *x, TItem Item){
    if((x == NULL)||(x->item.chave == Item.chave))
        return x;
    if(Item.chave < x->item.chave)
        return Pesquisar(x->esq,Item);
    else if(Item.chave > x->item.chave)
        return Pesquisar(x->dir, Item);
}

void Central(TCelula *x){
    if (x != NULL){
     Central(x->esq);
     printf("%d ",x->item.chave);
     Central(x->dir);
    }
}
void Central_Iterativa(TCelula *x){
    TItem ItemAux;
    TPilha PilhaAux;
    FPVazia(&PilhaAux);
    TCelula* y;
    while(x!=NULL && x ->esq!= NULL){
        x = x->esq;
        ItemAux.chave = x->item.chave;
        Empilhar(ItemAux,&PilhaAux);
    }
    while (!Vazia(PilhaAux)){
        Desempilhar(&PilhaAux,&ItemAux);
        x->item.chave = ItemAux.chave;
        if(x->dir!=NULL){
        x = x->dir;
        ItemAux.chave = x->item.chave;
        Empilhar(ItemAux,&PilhaAux);
        printf("SubArvoreEsq: %d ",x->item.chave);

        }
    }
     while(x != NULL){
        x = x->pai;
         if(x->pai == NULL){
             y = x;
            break;
         }
     }
    x= y;

    while(x != NULL&&x->dir!= NULL){
        x= x->dir;
        ItemAux.chave = x->item.chave;
        Empilhar(ItemAux,&PilhaAux);
    }

    while(!Vazia(PilhaAux)){
        Desempilhar(&PilhaAux,&ItemAux);
        x->item.chave = ItemAux.chave;
        if(x->esq!=NULL){
            x = x->esq;
            printf("AQUI: %d ",x->item.chave);
        }

    }

}

void PreOrdem(TCelula *x){
    if (x != NULL){
     printf("%d ",x->item.chave);
     PreOrdem(x->esq);
     PreOrdem(x->dir);
    }
}

void PosOrdem(TCelula *x){
    if (x != NULL){
     PosOrdem(x->esq);
     PosOrdem(x->dir);
     printf("%d ",x->item.chave);
    }
}

TCelula* Minimo(TCelula *x){
    if (x == NULL)
        return NULL;
    while(x->esq != NULL){
        x = x->esq;
    }
    return x;
}

TCelula* Maximo(TCelula *x){
    if (x == NULL)
        return NULL;
    while(x->dir != NULL){
        x = x->dir;
    }
    return x;
}

TCelula* Sucessor(TCelula *x){
    if(x == NULL)
        return NULL;
    if(x->dir != NULL)
        return Minimo(x->dir);
    TCelula *y = x->pai;
    while(y != NULL && x == y->dir){
        x = y;
        y = y->pai;
    }
    return y;
}

TCelula* Predecessor(TCelula *x){
    if(x == NULL)
        return x;
    if(x->esq != NULL)
        return Maximo(x->esq);
    TCelula* y = x->pai;
    while(y != NULL && x == y->esq){
        x = y;
        y = y->pai;
    }
    return y;
}
// Substitui sub�rvore enraizada no n� 'u' pela sub�rvore enraizada no n� 'v'.
void Transplante(TArvore *Arvore, TCelula **u, TCelula **v){
    if ((*u)->pai == NULL)
        Arvore->raiz = (*v);
    else if((*u) == (*u)->pai->esq)
        (*u)->pai->esq = (*v);
    else
        (*u)->pai->dir = (*v);
    if(*v != NULL)
        (*v)->pai = (*u)->pai;
}

// Retira um n� 'z' na �rvore 'Arvore'.
void Retirar(TArvore *Arvore, TCelula **z){
    if (*z == NULL){
        printf("\n>>>>> AVISO: NO' \"z\" E' NULO! <<<<<\n");
        return;
    }
    if((*z)->esq == NULL)
        Transplante(Arvore, z, &(*z)->dir);
    else if((*z)->dir == NULL)
        Transplante(Arvore, z, &(*z)->esq);
    else{
        TCelula *y = Minimo((*z)->dir);
        if(y->pai != (*z)){
            Transplante(Arvore, &y, &y->dir);
            y->dir = (*z)->dir;
            y->dir->pai = y;
        }
        Transplante(Arvore, z, &y);
        y->esq = (*z)->esq;
        y->esq->pai = y;
    }
    free(*z);
    *z = NULL;
}
void FPVazia(TPilha *Pilha){
  Pilha->topo = (TCelula*)
      malloc(sizeof(TCelula));
  Pilha->fundo = Pilha->topo;
  Pilha->topo->prox = NULL;
  Pilha->tamanho = 0;
}

int Vazia(TPilha Pilha){
 return (Pilha.topo == Pilha.fundo);
}

void Empilhar(TItem x,TPilha *Pilha){
  TCelula* Aux;
  Aux = (TCelula*)
         malloc(sizeof(TCelula));
  Pilha->topo->item = x;
  Aux->prox = Pilha->topo;
  Pilha->topo = Aux;
  Pilha->tamanho++;
}

void Desempilhar(TPilha *Pilha,TItem *Item){
  TCelula* q;
  if (Vazia(*Pilha)) {
      printf("Erro: lista vazia\n");
      return 0;
  }
  q = Pilha->topo;
  Pilha->topo = q->prox;
  *Item = q->prox->item;
  free(q);
  Pilha->tamanho--;
}

void Imprimir(TPilha *Pilha){
    TPilha PilhaAux;
    TItem Item;
    FPVazia(&PilhaAux);


    // Pop de PIlha e Push em Pilha auxiliar
    while(!Vazia(*Pilha)){
        Desempilhar(Pilha, &Item);
        Empilhar(Item,&PilhaAux);
    }

    while(!Vazia(PilhaAux)){

        Desempilhar(&PilhaAux, &Item);
        printf("\n %d ",Item.chave);
        Empilhar(Item,Pilha);
        printf(" %d",Item.chave);
    }
    Liberar (&PilhaAux);// eliminar a c�lula cabe�a
}

void Liberar(TPilha *Pilha){
    TItem Item;
    while(!Vazia(*Pilha)){
        Desempilhar(Pilha, &Item);
    }
    free(Pilha->topo);
    printf("\n Pilha liberada");
}
